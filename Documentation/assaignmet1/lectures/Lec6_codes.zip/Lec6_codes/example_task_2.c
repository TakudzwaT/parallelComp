#include <stdlib.h>
#include <stdio.h>
#include <omp.h>

int main(int argc, char *argv[]){

	#pragma omp parallel num_threads(4)
	{
		printf("ID: %d ",omp_get_thread_num());
        printf("A ");
		printf("soccer ");
		printf("match ");
	}

	printf("\n");
return 0;
}
