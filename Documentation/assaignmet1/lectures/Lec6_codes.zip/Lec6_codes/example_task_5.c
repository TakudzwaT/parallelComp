#include<stdio.h>
#include<stdlib.h>
#include<omp.h>

int main(){
#pragma omp parallel num_threads (4)
{
	#pragma omp single
	{
		printf("A(%d) ",omp_get_thread_num());
		#pragma omp task
			printf("soccer(%d) ",omp_get_thread_num());
		#pragma omp task
			printf("match(%d) ",omp_get_thread_num());
		#pragma omp task
			printf("is Fun to watch\n ");
		#pragma omp taskwait
		printf("%d is fun to watch\n ", omp_get_thread_num());
	}
}
	printf("\n");
	return 0;
}

