#include<stdio.h>
#include<stdlib.h>
#include<omp.h>

int main(){
#pragma omp parallel num_threads(4)
{
	#pragma omp single
	{
		printf("A ");
		#pragma omp task
			printf("soccer ");
		#pragma omp task
			printf("match ");
		#pragma omp task
			printf("is Fun to watch ");
	}
}
	printf("\n");
	return 0;
}

