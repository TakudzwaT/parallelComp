#include <stdlib.h>
#include <stdio.h>
#include <omp.h>

int main(int argc, char *argv[]){

	#pragma omp parallel num_threads(4)
	{
		#pragma omp single
		{
		printf("A ");
		#pragma omp task
		printf("soccer ");
		#pragma omp task
		printf("match ");
		//#pragma omp taskwait
		printf("is fun to watch ");
		}
	}

	printf("\n");
return 0;
}
