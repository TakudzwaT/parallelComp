
#include<stdio.h>
#include<stdlib.h>
#include<omp.h>
long sFib(int n){
	long x, y;
	if(n<2)
		return n;
	else{
		x = sFib(n-1);
		y = sFib(n-2);
		return x+y;
	}
}
/* Parallelize the sFib() using OpenMP*/
long pFib(int n, int threshold) 
{
    return 0;
}

int main(int argc, char *argv[]){
	int n, iter = 2, threshold;
    long sRes, pRes;
	double start_time, s_time = 0.0, p_time = 0.0;
    if(argc != 3){
		printf("Enter the number n for nth Fibonacci number and the cut_off value.\n");
		exit(EXIT_FAILURE);
	}
	n=atoi(argv[1]);
    threshold = atoi(argv[2]);
	
	start_time = omp_get_wtime();
	for(int k=0; k<iter;k++){
		sRes = sFib(n);
		s_time += omp_get_wtime() - start_time;
	}
	s_time = s_time/iter;
	/*Call the parallel function pRes here in the similar 
	way as sRes being called, and compare the performance.*/    
    start_time = omp_get_wtime();
	for(int k=0; k<iter;k++){
		pRes = pFib(n, threshold);
		p_time += omp_get_wtime() - start_time;
	}
	p_time = p_time/iter;	

	/* Check the correctness and compute the speed-up */	
	if(sRes==pRes)
		printf("The %dth Fibonacci number is: %ld; s: %f, p: %f, speed up: %f\n", n, pRes,s_time,p_time,s_time/p_time);
	else 
		printf("Error, the results from sequential and parallel computations are not the same.\n");
	return 0;
}


