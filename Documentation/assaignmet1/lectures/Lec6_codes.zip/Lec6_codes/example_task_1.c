#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[]){

	printf("A ");
	printf("soccer ");
	printf("match ");

	printf("\n");
return 0;
}
